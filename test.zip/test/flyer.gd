extends CharacterBody2D

const SPEED = 3000.0
signal dead

@export var max_health = 25
@onready var health = max_health

var direction = 1
var can_check = false
@export var damage = 1
@export var limit : int
@export var acceleration : int
@export var left_right = false
@export var up_down = false
@export var start_direction_y = 1

####### BASIC ATTACK EXPORTS ##########
@export_range(0,30) var attack_wait : float
@export_range(0,60) var attack_cooldown : float
@export_range(0,5) var attack_time : float

###### OUR DASH ATTACK VARIABLES ###########
@export_group("Dash_Attack")
@export var can_dash = false
@export var dash_multiplyer = 1.0

@onready var starting_y = position.y
@onready var starting_x = position.x
var player_in_range = false
var attacking = false
var returning = false
var target_pos_x
var target_pos_y
var dash_acceleration
@onready var start_pos_x = position.x
var start_pos_y
#########################################

####### PROJECTILE ATTACK VARIABLES ########
@export_group("Blast Attack (Can not blast & dash)")
@export var can_blast = false
@export var blast_acceleration = 0
var blasting = false
############################################

var universal_delta = 0
##########################################

func _physics_process(delta: float) -> void:
	universal_delta = delta
	# Add the gravity.
	#if not is_on_floor():
		#velocity += get_gravity() * delta
	
	#position = position.move_toward(Vector2(0, 0), 100 * universal_delta)
	
	if !attacking:
		if !returning:
			#print("FLY")
			if up_down:
				velocity.y = -acceleration * direction * delta * start_direction_y
			if left_right:
				velocity.x = -acceleration * direction * delta
			#print(velocity.y)
		if returning:
			#print("HI")
			position = position.move_toward(Vector2(start_pos_x, start_pos_y), dash_acceleration * universal_delta)
			if position == Vector2(start_pos_x, start_pos_y):
				returning = false
				attacking = false
	else:
		position = position.move_toward(Vector2(target_pos_x, target_pos_y), dash_acceleration * universal_delta)
		if position == Vector2(target_pos_x, target_pos_y):
			returning = true
			attacking = false
		
	if limit != -1:
		if up_down and !left_right:
			if position.y <= starting_y - limit:
				direction = -1
			if position.y >= starting_y:
				direction = 1
		
		if left_right:
			if position.x <= starting_x - limit:
				direction = -1
			if position.x >= starting_x:
				direction = 1
	
	#print(direction)
	#print(velocity.x)
	#print("________________________")
	check_rayCast()
	
	if (health <= 0):
		die()

	move_and_slide()
	

#$UpCast.is_colliding() or $DownCast.is_colliding() or 
#$UpCast.is_colliding() or $DownCast.is_colliding() or 
func check_rayCast():
	if ($RightCast.is_colliding() or $DownCast.is_colliding()):
		if ($DownCast.is_colliding()):
			direction = 1 * start_direction_y
		else:
			direction = 1
	if ($UpCast.is_colliding() or $LeftCast.is_colliding()):
		if ($UpCast.is_colliding()):
			direction = -1 * start_direction_y
		else:
			direction = -1
	#print(direction)

func die():
	direction = 0
	attacking = false
	$Hurtbox/CollisionShape2D.disabled = true
	$AnimatedSprite2D.play("Death")
	await $AnimatedSprite2D.animation_finished
	emit_signal("dead")
	free()


func _on_hurtbox_body_entered(body: Node2D) -> void:
	if body.is_in_group("Player"):
		if body.vtotal > 300 and body.reading_enemy and !attacking:
			get_hit(body)
		else:
			hit_player(body)
	
	else:
		if attacking and !body.is_in_group("Player"):
			returning = true
			attacking = false

func get_hit(body: Node2D):
	var damage_to_self = floor(body.vtotal / 100)
	body.hitstop(0.01 * damage_to_self)
	health -= damage_to_self
	
	print("HIT. Damage - ", damage_to_self, " Health - ", health, " Hitstop - ", damage * 0.01)

func hit_player(body: Node2D):
	body.health -= damage
	body.vtotal = body.vtotal * 0.5


func _on_target_detector_body_entered(body: Node2D) -> void:
	if body.is_in_group("Player"):
		player_in_range = true
		if can_dash:
			dash(body)
		elif  can_blast:
			blast_attack(body)

func _on_target_detector_body_exited(body: Node2D) -> void:
	if body.is_in_group("Player"):
		player_in_range = false

func dash(body: Node2D):
	await get_tree().create_timer(attack_wait).timeout
	
	target_pos_x = body.position.x
	target_pos_y = body.position.y
	dash_acceleration = acceleration * dash_multiplyer * universal_delta #* universal_delta
	attacking = true
	returning = false
	
	
	start_pos_y = position.y
	
	#var target_velocity_x = dash_acceleration * cos(angle) * universal_delta
	#var target_velocity_y = dash_acceleration * sin(angle) * universal_delta
	#
	#velocity.x = target_velocity_x
	#velocity.y = target_velocity_y
	#
	await get_tree().create_timer(attack_time).timeout
	##print("Hi")
	if attacking:
		returning = true
		attacking = false
	
	await  get_tree().create_timer(attack_cooldown).timeout
	if player_in_range:
		dash(body)
	
	#die()
	
	
func blast_attack(body : Node2D):
	await get_tree().create_timer(attack_wait).timeout
	
	#print("Current pos: ", body.position, " Target Pos: ", Vector2(final_x_player, final_y_player))
	
	#await get_tree().create_timer(attack_wait).timeout
	$Blast.show()
	$Blast.play("Fire")
	await $Blast.animation_finished
	$Blast.play("Fly")
	
	## MOVE THE SECTIONED OFF BLOCK TO BEFORE $Blast.show() IF TOO BUGGY
	var displacement_x_player = body.vx #* (attack_wait + 1)
	var displacement_y_player = body.vy #* (attack_wait + 1)
	
	var final_x_player = body.position.x + displacement_x_player
	var final_y_player = body.position.y - displacement_y_player
	#############################################################
	
	var displacement_blast_x = final_x_player - position.x
	var displacement_blast_y = final_y_player - position.y
	
	#print("Player pos: ", body.position, " Enemy Pos:", position, " Target Pos:", Vector2(final_x_player, final_y_player) )
	
	var angle = atan(displacement_blast_y / displacement_blast_x)
	var blast_velocity_x = blast_acceleration * universal_delta * cos(angle)
	var blast_velocity_y = blast_acceleration * universal_delta * sin(angle)
	
	if (body.position.y < position.y):
		blast_velocity_y = -1 * abs(blast_velocity_y)
	if (body.position.y > position.y):
		blast_velocity_y = abs(blast_velocity_y)
	
	if (body.position.x > position.x):
		blast_velocity_x = abs(blast_velocity_x)
	if (body.position.x < position.x):
		blast_velocity_x = -1 * abs(blast_velocity_x)
	
	$Blast.acceleration_x = blast_velocity_x / universal_delta
	$Blast.acceleration_y = blast_velocity_y / universal_delta
	blasting = true
	
	await get_tree().create_timer(attack_time).timeout
	$Blast.hide()
	#print("Back!")
	$Blast.acceleration_x = 0
	$Blast.acceleration_y = 0
	$Blast.position = Vector2.ZERO
	blasting = false
	#print("Position: ", position, " Blast Position: ", $Blast.position)
	
	await get_tree().create_timer(attack_cooldown).timeout
	if player_in_range:
		#print("HERE WE GO AGAIN")
		blast_attack(body)


func _on_blast_hitbox_body_entered(body: Node2D) -> void:
	if body.is_in_group("Player") and blasting:
		hit_player(body)
