extends CharacterBody2D

const SPEED = 3000.0

@export var max_health = 25
@onready var health = max_health

var direction = 1
var can_check = false
@export var damage = 1
@export var height : int
@export var speed : int


func _ready() -> void:
	var animation = $AnimationPlayer.

func _physics_process(delta: float) -> void:
	# Add the gravity.
	if not is_on_floor():
		velocity += get_gravity() * delta

	#velocity.x = direction * SPEED * delta
	#print(direction)
	#print(velocity.x)
	#print("________________________")
	#check_rayCast()
	
	if (health <= 0):
		die()

	move_and_slide()
	
	
func die():
	direction = 0
	$Hurtbox/CollisionShape2D.disabled = true
	$AnimatedSprite2D.play("Death")
	await $AnimatedSprite2D.animation_finished
	free()


func _on_hurtbox_body_entered(body: Node2D) -> void:
	if body.is_in_group("Player"):
		if body.vtotal > 300 and body.reading_enemy:
			get_hit(body)
		else:
			hit_player(body)

func get_hit(body: Node2D):
	damage = floor(body.vtotal / 100)
	body.hitstop(0.01 * damage)
	health -= damage
	
	print("HIT. Damage - ", damage, " Health - ", health, " Hitstop - ", damage * 0.01)

func hit_player(body: Node2D):
	body.health -= 1
	body.vtotal = body.vtotal * 0.5
