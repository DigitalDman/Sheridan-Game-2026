extends RigidBody2D # Export variables to tweak in the inspector
#defining variables
signal just_jumped

var reading_enemy = false
var rot: float = 1.6
@export var grav: int = 15
@export var tutorial = false
var vy:float = 0
var vx:float = 0
var vtotal:float = 0
var idk:int = 1
var windy: int = 0
var windx: int=0

var grounded = true
var slowdown_rate = 0.9

@export_group("Camera Limits")
@export var left_limit = -10000000
@export var right_limit = 10000000
@export var top_limit = -10000000
@export var bottom_limit = 10000000

@onready var health = GloablPlayerData.current_health
@onready var max_health = GloablPlayerData.max_health

func _ready() -> void:
	$Camera2D/Bars_And_Displays/TextureProgressBar.max_value = max_health
	$Camera2D.limit_bottom = bottom_limit
	$Camera2D.limit_right = right_limit
	$Camera2D.limit_left = left_limit
	$Camera2D.limit_top = top_limit

func back_in_air():
	await get_tree().create_timer(0.25).timeout
	rot = rotation
	grounded = false
	center_of_mass.y = 10
	physics_material_override.friction = 0.5

func reading_ground():
	await get_tree().create_timer(0.25).timeout
	grounded = true

func _process(delta: float) -> void:
	if (tutorial):
		$Tutorial_Box.rotation = -rotation
	$RayCasts/Ground_Cast_1.rotation = -rotation
	$RayCasts/Right_Cast.rotation = -rotation
	$RayCasts/Up_Cast.rotation = -rotation
	$RayCasts/Left_Cast.rotation = -rotation
	#$CollisionShape2D.rotation = -rotation
	
	$Bars_And_Displays/TextureProgressBar.value = health
	$Bars_And_Displays.rotation = -rotation
	
	if $RayCasts/Ground_Cast_1.is_colliding():
		reading_ground()
	
	if grounded and !($RayCasts/Ground_Cast_1.is_colliding()):
		emit_signal("just_jumped")
		
		
	if grounded:
		vtotal /= 1.01
		
		if (Input.is_action_pressed("Jump")):
			linear_velocity.y = -900
			emit_signal("just_jumped")
			#if grounded:
				#back_in_air()
	
	if $RayCasts/Enemy_Reader.is_colliding() or $RayCasts/Enemy_Reader2.is_colliding() or $RayCasts/Enemy_Reader3.is_colliding() or $RayCasts/Enemy_Reader4.is_colliding() or $RayCasts/Enemy_Reader5.is_colliding():
		reading_enemy = true
	else:
		reading_enemy = false
	
	#print("Vtotal - ", vtotal, " Vx - ", vx, " Vy - ", vy)

func _physics_process(delta):
	vx = vtotal*sin(rot) +windx #set vx
	vy = -vtotal*cos(rot)+grav -windy#set vy + gravity
	if !grounded:
		
		if (windy > 0):
			rot -= 0.06 * sin(rot)# * (windy / 100)
		if (windy < 0):
			rot += 0.06 * sin(rot)
		
		if (windx > 0):
			rot += 0.09 * cos(rot)
		if (windx < 0):
			rot -= 0.09 * cos(rot)
		
		#if (vtotal >= 40):
			#vtotal = vtotal*0.25 #soft speed cap
		#if (abs(vx) >= 500):
			#vx = vx*slowdown_rate
		if (vy >= 350):
			vy = vy*0.9
		if Input.is_action_pressed("ui_left"): #steering
			rot -= 0.06
		if Input.is_action_pressed("ui_right"):
			rot += 0.06
		
		if $RayCasts/Right_Cast.is_colliding() and sin(rot) > 0:
			vx = 0
		if $RayCasts/Left_Cast.is_colliding() and sin(rot) < 0:
			vx = 0
		
		linear_velocity = Vector2(vx, vy) #moves player
		
		vtotal = sqrt(vx*vx+vy*vy) #converts x into y or visa versa
		
		if (abs(vx)>=200):
			if (vtotal > 300):
				idk = 0
			#print("ZOOM")
				if (idk == 0 and vx != 0 and windx == 0):
					rot -= (0.04)*sin(rot)
					if (abs(vx) < 5):
						#print("HI")
						idk = 1
		if (100>=abs(vy)):
			rot += 0.03*sin(rot)
			#print("Slowing down")
		#print("-----------------------------")
		#print("VX: ", vx)
		#print("VY: ", vy)
		#print("Vtotal: ", vtotal)
		#print("rotation", rot)
		#print("-----------------------------")
		
		rotation = rot

func _on_area_2d_area_entered(area: Area2D) -> void:
	if area.is_in_group("Wind Tunnel"):
		windy += area.wind_powerY
		windx += area.wind_powerX
		slowdown_rate = 0.98
	
	#print(windx)


func _on_area_2d_area_exited(area: Area2D) -> void:
	windy = 0
	windx = 0
	
	await get_tree().create_timer(0.75).timeout
	slowdown_rate = 0.9
	#print("HI")


func _on_body_entered(body: Node) -> void:
	if body.is_in_group("Platforms") and $RayCasts/Face_Cast.is_colliding() and $RayCasts/Ground_Cast_1.is_colliding():
		grounded = true
	
	if body.is_in_group("Platforms"):
		#if $Right_Cast.is_colliding() or $Left_Cast.is_colliding():
			#vx = 0
			#print(vx)
		if $RayCasts/Up_Cast.is_colliding():
			vy = 0

func _on_body_exited(body: Node) -> void:
	back_in_air()


func _on_just_jumped() -> void:
	back_in_air()

func hitstop(duration: float):
	get_tree().paused = true
	# Await the duration time
	await get_tree().create_timer(duration, true).timeout
	
	get_tree().paused = false
