extends Node
var paused = false
var turn_tutorial_complete = false
var wind_tunnel_tutorial_complete = false
var grounding_tutorial_complete = false
var MultiDirectional_tutorial_complete = false
var enemy_tutorial_complete = false

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	if paused:
		if Input.is_action_just_pressed("Jump"):
			$"../Player/Tutorial_Box".hide()
			$"../Player/Tutorial_Box/Rotate & Move".hide()
			$"../Player/Tutorial_Box/Speed".hide()
			$"../Player/Tutorial_Box/Wind Tunnels".hide()
			$"../Player/Tutorial_Box/Grounding".hide()
			$"../Player/Tutorial_Box/Multidirectional".hide()
			$"../Player/Tutorial_Box/Enemies".hide()
			get_tree().paused = false


func _on_void_area_entered(area: Area2D) -> void:
	if area.is_in_group("Player"):
		$Player.position = Vector2(0,0)


func _on_turning_tutorial_area_entered(area: Area2D) -> void:
	if !turn_tutorial_complete and area.is_in_group("Player"):
		$"../Player/Tutorial_Box".show()
		$"../Player/Tutorial_Box/Speed".show()
		$"../Player/Tutorial_Box/Rotate & Move".show()
		paused = true
		turn_tutorial_complete = true
		get_tree().paused = true


func _on_wind_tunnel_tutorial_area_entered(area: Area2D) -> void:
	if !wind_tunnel_tutorial_complete and area.is_in_group("Player"):
		$"../Player/Tutorial_Box".show()
		$"../Player/Tutorial_Box/Wind Tunnels".show()
		paused = true
		wind_tunnel_tutorial_complete = true
		get_tree().paused = true


func _on_grounding_tutorial_area_entered(area: Area2D) -> void:
	if !grounding_tutorial_complete and area.is_in_group("Player"):
		$"../Player/Tutorial_Box".show()
		$"../Player/Tutorial_Box/Grounding".show()
		paused = true
		grounding_tutorial_complete = true
		get_tree().paused = true


func _on_wind_tunnel_tutorial_2_area_entered(area: Area2D) -> void:
	_on_wind_tunnel_tutorial_area_entered(area)


func _on_grounding_tutorial_2_area_entered(area: Area2D) -> void:
	_on_grounding_tutorial_area_entered(area)

 
func _on_multi_directional_tutorial_area_entered(area: Area2D) -> void:
	if !MultiDirectional_tutorial_complete and area.is_in_group("Player"):
		$"../Player/Tutorial_Box".show()
		$"../Player/Tutorial_Box/Multidirectional".show()
		paused = true
		MultiDirectional_tutorial_complete = true
		get_tree().paused = true


func _on_flyer_no_projectile_dead() -> void:
	$Platforms/Enemy_Tutorial_Platform.free()


func _on_enemy_tutorial_area_entered(area: Area2D) -> void:
	if !enemy_tutorial_complete and area.is_in_group("Player"):
		$"../Player/Tutorial_Box".show()
		$"../Player/Tutorial_Box/Enemies".show()
		paused = true
		enemy_tutorial_complete = true
		get_tree().paused = true
