extends Node


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass


func lightning():
	var rng = RandomNumberGenerator.new()
	rng.randomize()
	var lightning_wait = rng.randi_range(3,10)
	var random_pitch = rng.randf_range(0.4, 1.3)
	await get_tree().create_timer(lightning_wait).timeout
	
	$AudioStreamPlayer.pitch_scale = random_pitch
	$AudioStreamPlayer.play()
	$DirectionalLight2D/AnimationPlayer.play("flash")
	
	await  $DirectionalLight2D/AnimationPlayer.animation_finished
	lightning()


func _on_thunder_area_body_entered(body: Node2D) -> void:
	if body.is_in_group("Player"):
		$DirectionalLight2D/AnimationPlayer.play("flash")
		$AudioStreamPlayer.play()
		await  $DirectionalLight2D/AnimationPlayer.animation_finished
		lightning()
		$ThunderArea/CollisionShape2D.disabled = true
