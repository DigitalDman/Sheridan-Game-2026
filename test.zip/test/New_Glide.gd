extends RigidBody2D# Export variables to tweak in the inspector
@export var engine_thrust: float = 100.0
@export var spin_thrust: float = 5000.0

@export var lift_coeficient : float = 500.0
@export var wing_area : float = 5.0
@export var volume : float = 2.0
@export var glider_velocity : float = 2.0
var lift_float = 0.0

func _integrate_forces(state):
	pass
	
func _process(delta: float) ->void:
	#linear_velocity.x = 10000 * delta
	pass
#defining variables
var rot: float = 1.6
@export var grav: int = 15
var vy:float = 0
var vx:float = 0
var vtotal:float = 0
var idk:int = 1

func _physics_process(delta):
	vx = vtotal*sin(rot) #set vx
	vy = -vtotal*cos(rot)+grav #set vy + gravity
	#if (vtotal >= 40):
		#vtotal = vtotal*0.25 #soft speed cap
	if (vx >= 450):
		vx = vx*0.9
	if (vy >= 450):
		vy = vy*0.9
	if Input.is_action_pressed("ui_left"): #steering
		rot -= 0.06
	if Input.is_action_pressed("ui_right"):
		rot += 0.06
	
	linear_velocity = Vector2(vx, vy) #moves player
	
	vtotal = sqrt(vx*vx+vy*vy) #converts x into y or visa versa
	
	if (abs(vx)>=500):
		if (vtotal > 500):
			idk = 0
		#print("ZOOM")
			if (idk == 0):
				rot -= (0.04)*sin(rot)
				if (abs(vx) < 5):
					#     print("HI")
						idk = 1
	if (40>=abs(vy)):
		rot += 0.03*sin(rot)
		#print("Slowing down")
	print("-----------------------------")
	print("VX: ", vx)
	print("VY: ", vy)
	print("Vtotal: ", vtotal)
	print("rotation", rot)
	print("-----------------------------")
	
	rotation = rot
