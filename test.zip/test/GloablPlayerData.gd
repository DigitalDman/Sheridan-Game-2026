extends Node

var current_health = 10
var max_health = 10
