extends Area2D
var player_in = false
@export var damage = 1
@export var bounce_back = 500

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass

func poke(body):
	body.grounded = true
	body.linear_velocity.y = -bounce_back
	body.emit_signal("just_jumped")
	body.health -= damage
	
	await get_tree().create_timer(1).timeout
	if player_in:
		poke(body)


func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("Player"):
		player_in = true
		poke(body)


func _on_body_exited(body: Node2D) -> void:
	if body.is_in_group("Player"):
		player_in = false
